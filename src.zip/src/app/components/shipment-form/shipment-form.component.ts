import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ShipmentService } from '../../services/shipment.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-shipment-form',
  templateUrl: './shipment-form.component.html',
  styleUrls: ['./shipment-form.component.scss']
})
export class ShipmentFormComponent implements OnInit {
  form!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private shipmentService: ShipmentService,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      trackingId: ['', Validators.required],
      phoneNumber: ['', [Validators.required, Validators.minLength(10)]],
      description: [''],
    });
  }

  onSubmit(): void {
    console.log('Submit triggered', this.form.value); // Debug log

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.shipmentService.create(this.form.value).subscribe({
      next: () => this.router.navigate(['/shipments']),
      error: err => {
        console.error('Create failed', err);
        alert('Failed to create shipment. See console for details.');
      }
    });
  }
}
